package com.example.flickr

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
